<?php
require_once '../src/databaseConnect/Database.php';

/*
 * CST-256 Database Application Programming 3
 * Vien Nguyen
 * UserDataService class
 *  Jan/22nd/20
 * This class is working as database service for CRUD.
 * */
class UserDataService{
    
    //Login function. The function will open a coonnection to the database. 
    //Select a record where email and password equal to the attributes of email and password in user object.
    function userLogin($user){
        //Open connection
        $db = new Database();
        //Query to the database
        $sql_query = "SELECT * FROM user WHERE  email = '".$user->getEmail()."' AND password = '".$user->getPassword()."'";
        //Get connection
        $Connection = $db->getConnection();
        //Execute the query for a result
        $result = $Connection->query($sql_query);
        //Return the result
        return $result->num_rows;
        
    }
    //user Register function.
    //Create a user record into the database using $user attributes.
    function userRegister($user){
        //Open Database connection
        $db = new Database();
        //Query to insert database 
        $sql = "INSERT INTO user (firstname, lastname, email, password) 
                VALUES('".$user->getFirstName()."'
                      ,'".$user->getLastName()."'
                      ,'".$user->getEmail()."'
                      ,'".$user->getPassword()."')";
        if($db->getConnection()->query($sql)===true){
           return view('home');
        }else{
           return view('register');
        }
    }
    
}