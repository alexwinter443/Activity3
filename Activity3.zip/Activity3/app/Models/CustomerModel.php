<?php

namespace App\Models;

class CustomerModel{
    
    private $firstName;
    private $lastName;
    private $id;
      
    /**
     * @return mixed
     */
    public function getFirstName()
    {
        return $this->firstName;
    }

    /**
     * @return mixed
     */
    public function getLastName()
    {
        return $this->lastName;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $firstName
     */
    public function setFirstName($firstName)
    {
        $this->firstName = $firstName;
    }

    /**
     * @param mixed $lastName
     */
    public function setLastName($lastName)
    {
        $this->lastName = $lastName;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    // Class Constructor
    public function __construct($firstName, $lastName){
        
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        
        
    }
    
   
}