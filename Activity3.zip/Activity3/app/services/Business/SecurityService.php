<?php

namespace App\services\Business;

use App\Models\UserModel;
use App\Services\Data\SecurityDAO;
use App\services\data\CustomerDAO;
use app\Models\CustomerModel;
use App\services\data\OrderDAO;
use App\services\data\utility\DatabaseConnection;

///THIS IS DONE!
class SecurityService{
    
    private $verifyCred;
    
    
    public function login(UserModel $credentials){
        
        // Instantiate the data Access layer
        $this->verifyCred = new SecurityDAO();
         
        // return true or false by passing credentials to the object
        return $this->verifyCred->findByUser($credentials);       
    }
    
    public function addCustomer(CustomerModel $customerData){
        $this->addNewCustomer = new CustomerDAO();
        return $this->addNewCustomer->addCustomer($customerData);
    }
    
    public function addOrder(string $product, int $customerID){
        $this->addNewOrder = new OrderDAO();
        return $this->addNewOrder->addOrder($product, $customerID);
    }
    
    
    public function AddAllInformation(string $product, int $customerID, CustomerModel $customerData){
        // create a connection to the database
        $conn = new DatabaseConnection("activity2");
        
        $dbObj = $conn->getConnection();
        
        $conn->setDBAutoCommiFalse();
        
        $conn->beginTransaction();
        
        $this->addNewCustomer = new CustomerDAO($dbObj);
        
        $customerID = $this->addNewCustomer->getNextId();
        
        
        $isSuccessful = $this->addNewCustomer->addCustomer($customerData);
        
        $this->addNewOrder = new OrderDAO($dbObj);
        
        $isSuccessfulOrder = $this->addNewOrder->addOrder($product, $customerID);
        
        if($isSuccessful && $isSuccessfulOrder){
            $conn->commitTransaction();
            return true;
        }
        else{
            $conn->rollbackTransaction();
            return false;
        }
        
        
    }
    
    
}
