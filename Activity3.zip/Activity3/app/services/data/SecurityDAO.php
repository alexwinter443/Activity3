<?php

namespace App\services\data;

use App\Models\UserModel;
use Carbon\Exceptions\Exception;

class SecurityDAO{
    
    // Define the connection string
    private $conn;
    private $dbserverName = "localhost";
    private $dbusername = "root";
    private $dbpassword = "root";
    private $dbname = "activity2";
    private $dbQuery = "" ;
    
    // constructor that creates a connection with the database
    public function __construct(){
        $this->conn = new \mysqli($this->dbserverName, $this->dbusername, $this->dbpassword, $this->dbname);
        
        //$this->conn = mysqli_connect($this->dbserverName, $this->dbusername, $this->dbpassword, $this->dbname);
        
        if($this->conn->connect_error){
            echo("Connection failed " .$this->conn->connect_error . "<br>");
        }else{
            return $this->conn;
        }
        // make sure to test the connection to see if there are any errors
        
    }
    
    /*
     * Method to verify User Credentials
     */
    
    public function findByUser(UserModel $credentials1){
        
        try{
           // SQL Statement
           $dbQuery = "SELECT * FROM user WHERE Username = '" . $credentials1->getUsername() . "' AND Password = '" .
           $credentials1->getPassword() . "'";
                    
           // If the selected query returns a result set
           $result = $this->conn->query($dbQuery);
           
           //Returns 1
           return $result->num_rows;
        }
        catch(Exception $e){
            echo "hello";
        }
        
        
    }
    
}