<?php
namespace App\services\data;


use Carbon\Exceptions\Exception;

class OrderDAO{
    
    private $conn;
    private $dbName = "activity2";
    private $dbQuery;
    private $connection;
    private $dbObj;
    
    public function __construct($dbObj){
        
        // create a connection to the database
        // create an instance of the class
        
        $this->dbObj = $dbObj;
        
//         $this->conn = new DatabaseConnection();
//         $this->connection = $this->conn;

           
    }
    
    public function addOrder(string $product, int $customerID){
        
        try{
//             $db = new DatabaseConnection();
            
//             $this->conn = $db->getConnection();
            
            
            
            $this->dbQuery = "INSERT INTO order1 (Product, customerID) VALUES ('" . $product . "', " . $customerID . ")"; 
            
            if($this->dbObj->query($this->dbQuery)){
                
                //$this->conn->close();
                return true;
            }
            else{
                //$this->db->close();
                return false;
            }
            
        }
        
        catch(Exception $e){
            echo "something went wrong";
        }
    }
    
    
    public function getNextId(){
        try{
            
            $this->dbQuery = "SELECT id FROM customer ORDER BY id DESC LIMIT 0,1";
            
            $result = $this->dbObj->query($this->dbQuery);
            //$result = $this->conn->query($this->dbQuery);
            while($row = mysqli_fetch_array($result)){
                // point to the next row that has not been committed yet
                return $row['id'] + 1 ;
            }
        }
        catch(\Exception $e){
            
            echo $e->getMessage();
        }
    }
    
    
}