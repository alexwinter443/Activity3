<?php
namespace App\services\data;


use app\Models\CustomerModel;
use Carbon\Exceptions\Exception;
use app\services\data\utility\DatabaseConnection;

class CustomerDAO{
    
    private $conn;
    private $dbName = "activity2";
    private $dbQuery;
    private $connection;
    private $dbObj;
    
    public function __construct($dbObj){
        
        // create a connection to the database
        // create an instance of the class
        $this->dbObj = $dbObj;
        
        
//         $this->conn = new DatabaseConnection2($this->dbname);
//         $this->connection = $this->conn->getDBConnect();
    }
    
    public function addCustomer(CustomerModel $customerdata){
        
        try{
            $this->dbQuery = "INSERT INTO customer (firstName, lastName) VALUES ('{$customerdata->getFirstName()}',
             '{$customerdata->getLastName()}')";
            
            if($this->dbObj->query($this->dbQuery)){
                //$this->conn->closeDBConnect();
                return true;
            }
            else{
                //$this->conn->closeDBConnect();
                return false;
            }
            
        }
        
        catch(Exception $e){
            echo "something went wrong";
        }
    }
    
    
    /// DONE MAYBEEE
    public function getNextId(){
        try{
            
            $this->dbQuery = "SELECT id FROM customer ORDER BY id DESC LIMIT 0,1";
            
            $result = $this->dbObj->query($this->dbQuery);
            //$result = $this->conn->query($this->dbQuery);
            while($row = mysqli_fetch_array($result)){
                // point to the next row that has not been committed yet
                return $row['id'] + 1 ;
            }
        }
        catch(\Exception $e){
            
            echo $e->getMessage();
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
}