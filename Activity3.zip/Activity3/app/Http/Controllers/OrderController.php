<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\Business\SecurityService;
use App\Models\CustomerModel;


class OrderController extends Controller
{
    // To obtain an instance of the current http request from the post
    
    // THIS IS DONE!!!
    public function index (Request $request)
    {
        // put the customer data in a model
        $customerData = new CustomerModel(request()->get('firstName'), request()->get('lastName'));
        
        // since we are not using a model this time 
        $product  = request()->get('product');
        // this is more effecient since it is not calling a method
        $customerID = $request->input('customerID');

        $serviceCustomer = new SecurityService();
        
        $isValid = $serviceCustomer->addAllInformation($product, $customerID, $customerData);
        
        if($isValid){
            echo ("<br>order data comitted successfully");
        }
        else{
            echo "<br>order data was rolled back";
        }
        return view('Order');
        
             
             
    }
    
    public function validateForm(Request $request){
        
        $rules = ['username' => 'Required|Between: 4,10|Alpha', 'password' => 'Required|Between: 4,10' ];
        // Run Data Validation Rules
        $this->validate($request, $rules);     
        
    }
    
    
}
