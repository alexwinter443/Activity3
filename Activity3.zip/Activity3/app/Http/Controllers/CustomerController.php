<?php

namespace App\Http\Controllers;

use App\Models\CustomerDAO;
use App\Models\UserModel;
use App\Services\Business\SecurityService;
use Illuminate\Http\Request;
use app\Models\CustomerModel;


class CustomerController extends Controller
{
    // To obtain an instance of the current http request from the post
    
//     public function index (Request $request)
//     {
//         $add = new CustomerDAO();
        
//         $add->addCustomer("Billaa", "Nyaaa");
//         $this->validateForm($request);
//         // This is from the next step d. in the activity
//         // create a user model with username and password
//         $user = new UserModel($request->input('username'), $request->input('password'));
        
//         // Instantiate the business layer
//         $serviceLogin = new SecurityService();
        
//         // Pass the credentials to the business layer
//         // Should return a number of results
//         $isValid = $serviceLogin->login($user);
//         if($serviceLogin->login($user) > 0){
//             return view('loginPassed2')->with(compact('user'));
//         }
//         else{
//             return view('loginfailed');
//         }      
             
//     }

//     public function index (Request $request)
//     {
//         //$add = new CustomerDAO();

//         //add->addCustomer("Billaa", "Nyaaa");
        
//         $customerData = new CustomerModel($request->input('firstName'), $request->input('lastName'));
        
//         $serviceCustomer = new SecurityService();
        
//         $isValid = $serviceCustomer->addCustomer($customerData);
        
//         if($isValid){
//             echo ("Custmer data added successfully");
//             return view('Customer');
//         }
//         else{
//             echo "customer was not added";
//             return view('Customer');
//         }
    
//     }
    public function index (Request $request)
    {

        //$customerData = new CustomerModel(request()->get('firstName'), request()->get('lastName'));
        
        //testing
        $nextID = 0;
       
        return redirect('newOrder')->with('nextID', $nextID)
                                   ->with('firstName', request()->get('firstName'))
                                   ->with('lastName', request()->get('lastName')); 
    }
    
    
    public function validateForm(Request $request){
        
        $rules = ['username' => 'Required|Between: 4,10|Alpha', 'password' => 'Required|Between: 4,10' ];
        // Run Data Validation Rules
        $this->validate($request, $rules);     
        
    }
    
}
