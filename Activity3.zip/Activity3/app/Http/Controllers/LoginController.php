<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Services\Business\SecurityService;
use App\services\data\CustomerDAO;


class LoginController extends Controller
{
    // To obtain an instance of the current http request from the post
    
//     public function index (Request $request)
//     {
//         $add = new CustomerDAO($dbObj);
        
//         $add->addCustomer("Billaa", "Nyaaa");
//         $this->validateForm($request);
//         // This is from the next step d. in the activity
//         // create a user model with username and password
//         $user = new UserModel($request->input('username'), $request->input('password'));
        
//         // Instantiate the business layer
//         $serviceLogin = new SecurityService();
        
//         // Pass the credentials to the business layer
//         // Should return a number of results
//         $isValid = $serviceLogin->login($user);
//         if($serviceLogin->login($user) > 0){
//             return view('loginPassed2')->with(compact('user'));
//         }
//         else{
//             return view('loginfailed');
//         }      
             
//     }
    
    
    public function index (Request $request)
    {
        $add = new CustomerDAO($dbObj);
        
        $add->addCustomer("Billaa", "Nyaaa");
        $this->validateForm($request);
        // This is from the next step d. in the activity
        // create a user model with username and password
        $user = new UserModel($request->input('username'), $request->input('password'));
        
        // Instantiate the business layer
        $serviceLogin = new SecurityService();
        
        // Pass the credentials to the business layer
        // Should return a number of results
        $isValid = $serviceLogin->login($user);
        if($serviceLogin->login($user) > 0){
            return view('loginPassed2')->with(compact('user'));
        }
        else{
            return view('loginfailed');
        }
        
    }
    
    public function userLogin(Request $request){
        //Validate email and password
        $request->validate(
            [
                'username'=>'required',
                'password'=>'required|min:3|max:20',
            ]);
        //Initiates a userDataService object
        $userDataService = new SecurityService();
        
        //Initiates a User object
        $user = new UserModel($request->input('username'), $request->input('password'));
        //Set the properties for the user object
        $user->setUsername($request->input('username'));
        $user->setPassword($request->input('password'));
        // login method utilize sql code to check if user exists in table    
        $userDataService->login($user);
        //Passing the user into the userLogin method for login validation and return login result
        if($userDataService->login($user)!=0){
            return view('loginPassed2')->with('user', $user);
        }else{
            return view('login');
        }
        
    }
    
    public function validateForm(Request $request){
        
        $rules = ['username' => 'Required|Between: 4,10|Alpha', 'password' => 'Required|Between: 4,10' ];
        // Run Data Validation Rules
        $this->validate($request, $rules);     
        
    }
    
    
}
