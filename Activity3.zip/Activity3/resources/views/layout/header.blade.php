<html>
<h2>Welcome to Activity 2</h2>

</html>