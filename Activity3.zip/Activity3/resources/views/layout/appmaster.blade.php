<html lang = "en">
	<head>
		<title>@yield('title')</title>
	</head>
	<body>
		<div align = "center">
		@include('layout.header')
		</div>
		
		<div align = "center">
		@yield('content')
		</div>
		
		<div align = "center">
		@include('layout.footer')
		</div>
	</body>





</html>