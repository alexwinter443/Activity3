@if($user->getUsername() == 'alexvii')
	<h3>Alex you have successfully logged in</h3>
	
@else
	<h3>Someone beside Alex logged in successfully</h3>
	
@endif

