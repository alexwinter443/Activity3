<html>
<head><base>
<title>Add Customer</title>
</head>

<body>
	<div>
		<!--  this takes us to the route '/doLogin' within web.php -->
		<form action="addOrder" method="post">
		    <!-- hidden field that is required-->
		    <!-- TOKEN -->
			{{ csrf_field() }}
			
			<div class = "demo-table">
				<div class = "form-head">Order Product</div>
				<!-- Begin Product -->
				<div class="form-column">
					<div>
						<label for="product">Product</label><span id="product" class="error-info"></span>
					</div>	
					<div>
						<input name="product" id="product" type="text" class="demo-input-box">
					</div>		
				</div>
				<!-- End Username -->
				<!-- Password Form -->
				<div class="form-column">
					<div>
						<label for="customerID">Customer ID</label><span id="customerID" class="error-info"></span>
					</div>	
					<div>
						<input name="customerID" id="customerID" type="text" value="{{ Session:: get('nextID')}} " class="demo-input-box">
					</div>	
					
					<div>
						<input name="firstName" id="firstName" type="text" value="{{ Session:: get('firstName')}} " class="demo-input-box">
						
					</div>	
					
					<div>
						<input name="lastName" id="lastName" type="text" value="{{ Session:: get('lastName')}} " class="demo-input-box">		
					</div>	
				</div>
				<!-- End Password -->
				<div>
					<input type="submit" value="login" class="btnLogin" >
				</div>
			
			</div>
		
		</form>
	</div>



</body>

</html>