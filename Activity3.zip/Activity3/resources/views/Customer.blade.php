<html>
<head><base>
<title>Add Customer</title>
</head>

<body>
	<div>
		<!--  this takes us to the route '/doLogin' within web.php -->
		<form action="addCustomer" method="post">
		    <!-- hidden field that is required-->
		    <!-- TOKEN -->
			{{ csrf_field() }}
			
			<div class = "demo-table">
				<div class = "form-head">Add Customer</div>
				<!-- Username Form -->
				<div class="form-column">
					<div>
						<label for="firstName">First Name</label><span id="user_info" class="error-info"></span>
					</div>	
					<div>
						<input name="firstName" id="firstName" type="text" class="demo-input-box">
					</div>		
				</div>
				<!-- End Username -->
				<!-- Password Form -->
				<div class="form-column">
					<div>
						<label for="lastName">Last Name</label><span id="password_info" class="error-info"></span>
					</div>	
					<div>
						<input name="lastName" id="lastName" type="text" class="demo-input-box">
					</div>		
				</div>
				<!-- End Password -->
				<div>
					<input type="submit" value="login" class="btnLogin" >
				</div>
			
			</div>
		
		</form>
	</div>



</body>

</html>