<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// this route will fire when we type 'login' in the url

Route::get('/login', function(){
    return view('loginView');
    //echo('This is a test');
    
});

// when the data is posted from the login page
// with the action set to 'doLogin' it will com here
// Then the route the request to the function called index
// in the login controller
Route::post('/doLogin', 'LoginController@userLogin');


Route::get('/login2', function(){
   return view('loginView2'); 
});


Route::get('/what', function(){
    return view('what');
});

//--------------------------------------

Route::get('/customer', function(){
    return view('Customer');
});

Route::post('/addCustomer', 'CustomerController@index');


//--------------------------------------
Route::get('newOrder', function(){
   return view('Order');
    
});

Route::post('addOrder', 'OrderController@index');












